create function inserdate(val character varying) returns void
  language plpgsql
as
$$
declare 
tabmot text[];
i text;
BEGIN
	tabmot=regexp_split_to_array(val ,' ')	;															  															  
			  
 	IF (array_length(tabmot,1)=3) THEN
		INSERT INTO Date VALUES(nextval('seq_date'), tabmot[1],tabmot[2],tabmot[3]);															

	ELSE IF (array_length(tabmot,1)=2) THEN																	
		INSERT INTO Date VALUES(nextval('seq_date'), NULL,tabmot[1],tabmot[2]);
															 
		ELSE IF (array_length(tabmot,1)=1) THEN																 															   
			INSERT INTO Date VALUES(nextval('seq_date'), NULL,NULL,tabmot[1]);												 

			ELSE																  
				INSERT INTO Date VALUES(nextval('seq_date'), NULL,NULL,NULL);	
			END IF;
		END IF;
	END IF;
END
$$;

alter function inserdate(varchar) owner to postgres;

