create function insertville(ville character varying) returns void
  language plpgsql
as
$$
DECLARE
   j integer =1;
   i varchar ; 
   BEGIN
   FOR i in (Select d.ville from donnees d) LOOP
   --	INSERT INTO Localisation VALUES(j,i,NULL)  ;
   		j= j + 1;
   		raise notice '%', j ;
   	END LOOP;
   END
$$;

alter function insertville(varchar) owner to postgres;

