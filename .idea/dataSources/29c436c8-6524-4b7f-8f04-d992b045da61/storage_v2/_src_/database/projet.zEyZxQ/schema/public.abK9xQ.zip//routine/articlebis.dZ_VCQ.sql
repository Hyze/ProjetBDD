create function articlebis() returns trigger
  language plpgsql
as
$$
BEGIN
	IF NEW.discriminant = 'bis' THEN
		NEW.article = NEW.article || NEW.discriminant;
		NEW.discriminant = null;
	END IF;
	RETURN NEW;
END
$$;

alter function articlebis() owner to postgres;

