create function nettoieville() returns void
  language plpgsql
as
$$
declare
	i varchar ;
    tabmot varchar[];
	res text;
    begin
    for i in SELECt cast(ville as varchar )from donnees where ville like '%,%' loop
	res = (select Decoupe(i));
	raise notice '%',res;
	update donnees set ville = res where ville=i;
    end loop;
    end;
$$;

alter function nettoieville() owner to postgres;

