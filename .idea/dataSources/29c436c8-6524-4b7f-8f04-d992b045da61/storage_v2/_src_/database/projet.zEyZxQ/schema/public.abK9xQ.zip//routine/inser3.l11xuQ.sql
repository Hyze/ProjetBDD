create function inser3() returns void
  language plpgsql
as
$$
declare
tabmot text[];
BEGIN
	UPDATE info
		SET date = trim('Prise de vue : ' from date);
END
$$;

alter function inser3() owner to postgres;

