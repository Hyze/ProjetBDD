create function inserdet(datee integer, ville text, art text, sujet text, description text, notebasdepage text, index_personne text, fichier_num text, index_iconogrphique text) returns void
  language plpgsql
as
$$
DECLARE
i integer ;
j integer ;
n integer ; 
BEGIN
i:= (SELECT id_ville from localisation where nom_ville=ville );
j:= (select id_date from date where id_date = datee);
n := (select id_photo from detail_artistique,localisation where nom_ville=ville);
INSERT INTO detail_photo VALUES(n,i,j,art,sujet, description, notebasdepage , index_personne,fichier_num  ,index_iconogrphique );
END
$$;

alter function inserdet(integer, text, text, text, text, text, text, text, text) owner to postgres;

