create function inserart(nb text, neg text, coul text, remarque text, taille text) returns void
  language plpgsql
as
$$
BEGIN
INSERT INTO Detail_artistique VALUES(nextval('seq_deta'),nb ,neg,coul,remarque,taille);
END
$$;

alter function inserart(text, text, text, text, text) owner to postgres;

