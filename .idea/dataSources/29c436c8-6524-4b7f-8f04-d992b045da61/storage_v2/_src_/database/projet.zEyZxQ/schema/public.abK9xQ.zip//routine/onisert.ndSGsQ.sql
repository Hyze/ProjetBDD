create function onisert() returns trigger
  language plpgsql
as
$$
declare
 ville_temp text;
 BEGIN
 raise notice '%', NEW.nom_ville ;
  ville_temp  := (Select nom_ville from localisation where LOWER(nom_ville)=LOWER(NEW.nom_ville));
raise notice '%', ville_temp;
 IF LOWER(NEW.nom_ville) = LOWER(ville_temp) THEN
  UPDATE localisation set Latlambert93 = NEW.Latlambert93 where LOWER(nom_ville)= LOWER(new.nom_ville);
 update localisation set Longlambert93= new.Longlambert93 where LOWER(nom_ville)=LOWER(new.nom_ville);
 raise notice 'update done';
 END IF;
 RETURN null;
 END
$$;

alter function onisert() owner to postgres;

