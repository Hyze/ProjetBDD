create function inserdet(discriminant text, ville text, art text, sujet text, description text, notebasdepage text, index_personne text, fichier_num text, index_iconogrphique text) returns void
  language plpgsql
as
$$
DECLARE
i integer ;	
j integer ;																	  
BEGIN
i:= (SELECT id_ville from localisation where nom_ville=ville );																	  
INSERT INTO detail_photo VALUES(nextval('seq1'),i,nextval('seq2'),art,description ,sujet , notebasdepage , index_personne,fichier_num  ,index_iconogrphique );				  
END
$$;

alter function inserdet(text, text, text, text, text, text, text, text, text) owner to postgres;

