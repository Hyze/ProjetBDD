create function inser(ville character varying) returns void
  language plpgsql
as
$$
BEGIN
IF (LOWER(ville) NOT IN (select LOWER(nom_ville) from Localisation)) THEN
INSERT INTO Localisation VALUES(nextval('villeID'), ville,NULL,NULL);
END IF ;
END
$$;

alter function inser(varchar) owner to postgres;

