create function bis() returns void
  language plpgsql
as
$$
declare 
   tem text ;
   artval text ; 
   BEGIN
   for tem in select article from info where info.discriminant='bis' LOOP
   if tem !~ 'bis'then
   artval := tem || 'bis';
   raise notice '%',tem;
   update info set article=artval where article = tem ;																				  
   end if; 
   end loop;
   eND
$$;

alter function bis() owner to postgres;

