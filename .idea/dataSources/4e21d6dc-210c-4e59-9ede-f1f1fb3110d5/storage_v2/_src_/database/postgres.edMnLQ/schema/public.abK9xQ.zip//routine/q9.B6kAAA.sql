create function q9() returns void
  language plpgsql
as
$$
DECLARE
x RECORD;
BEGIN
FOR x IN SELECT c2 FROM foo LOOP
UPDATE foo
SET c3 = to_tsvector('french', x.c2)
WHERE c2 = x.c2;
END LOOP;
END;
$$;

alter function q9() owner to postgres;

