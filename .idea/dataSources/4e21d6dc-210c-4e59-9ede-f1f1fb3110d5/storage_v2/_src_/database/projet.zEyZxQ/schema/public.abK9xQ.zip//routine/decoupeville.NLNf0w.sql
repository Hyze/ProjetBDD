create function decoupeville() returns void
  language plpgsql
as
$$
DECLARE
 tabmot varchar[];
 x RECORD;
BEGIN
FOR x IN select article, ville FROM info where ville ~ ',' LOOP
    tabmot=regexp_split_to_array(x.ville, ',');
  UPDATE info
    SET ville=tabmot[1]
  WHERE article = x.article;
  END LOOP;
  FOR x IN select article, ville FROM info where ville ~ '--' LOOP
    tabmot=regexp_split_to_array(x.ville, '--');
  UPDATE info
    SET ville=tabmot[1]
  WHERE article = x.article;
  END LOOP;
END
$$;

alter function decoupeville() owner to postgres;

