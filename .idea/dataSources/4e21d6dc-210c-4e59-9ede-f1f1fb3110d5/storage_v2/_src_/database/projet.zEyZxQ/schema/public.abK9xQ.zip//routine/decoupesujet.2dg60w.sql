create function decoupesujet() returns void
  language plpgsql
as
$$
DECLARE
      tabmot text[];
      x RECORD;
      i integer;
      j integer;
      res text;
   BEGIN
   	FOR x IN select article, sujet FROM info where sujet =', ' OR sujet =', ,' LOOP
   		UPDATE info
   			SET sujet = NULL
   	    WHERE article = x.article;
   		END LOOP;
   	FOR x IN select article, sujet FROM info where sujet ~ ',' LOOP
   			tabmot=regexp_split_to_array(x.sujet, ',');
   			IF array_length(tabmot,1) =1 THEN
   				UPDATE info
   					SET sujet = tabmot[1]
   				WHERE article = x.article; 
   			END IF;
   			IF array_length(tabmot,1) =2 THEN
   				IF tabmot[1] != tabmot[2] THEN
   				res = array_to_string(tabmot, ',');
   					UPDATE info
   						SET sujet = res
   					WHERE article = x.article;
   				ELSE 
   					UPDATE info
   						SET sujet = Tabmot[1]
   					WHERE article = x.article;
   				END IF;
   			END IF;
   			/*IF array_length(tabmot,1) >2 THEN
   				FOR i IN 1..array_length(tabmot,1) LOOP
   					FOR j IN (i+1)..array_length(tabmot,1) LOOP
   						IF tabmot[i] != tabmot[j] THEN
   							res=res || array_to_string(tabmot, ', ');
   						END IF;
   					END LOOP;
   				END LOOP;
   			UPDATE donnees
   				SET sujet = res
   			WHERE article = x.article; 
   			END IF;*/
   	END LOOP;
   END
$$;

alter function decoupesujet() owner to postgres;

