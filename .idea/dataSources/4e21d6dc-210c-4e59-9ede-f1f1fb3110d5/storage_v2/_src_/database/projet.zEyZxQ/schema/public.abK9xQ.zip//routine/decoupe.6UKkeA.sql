create function decoupe(a character varying) returns text
  language plpgsql
as
$$
declare
   tabmot varchar[];
   retour text;
   i varchar ;
   begin
 tabmot=regexp_split_to_array( A, ',');                                                                                         --       retour=cast(tabmot[1]as text)	;
    retour=cast(tabmot[1]as text);
 return retour;
   end
$$;

alter function decoupe(varchar) owner to postgres;

