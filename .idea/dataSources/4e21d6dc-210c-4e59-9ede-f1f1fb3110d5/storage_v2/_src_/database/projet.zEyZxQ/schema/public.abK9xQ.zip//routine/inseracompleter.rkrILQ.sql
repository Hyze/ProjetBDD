create function inseracompleter(date text, article text, reference text, serie text, nom_ville text, sujet text, description text, index_personne text, nb_cliche text, negatif text, couleur text, discriminant text) returns void
  language plpgsql
as
$$
BEGIN
	IF nom_ville IS NULL OR date IS NULL OR serie IS NULL OR reference IS NULL THEN
												  
			INSERT INTO Acompleter VALUES(date ,article ,reference ,serie ,nom_ville,sujet,description,index_personne,nb_cliche,negatif,couleur,discriminant);
	END IF;
END
$$;

alter function inseracompleter(text, text, text, text, text, text, text, text, text, text, text, text) owner to postgres;

