create function nettoiesujet() returns void
  language plpgsql
as
$$
declare
	i varchar ; 
    tabmot varchar[];
	res text;
    begin
    for i in SELECt cast(sujet as varchar )from donnees where sujet like '%,%' loop
	res = (Select decoupe(i));
	raise notice '%',res;
	update donnees set sujet = res;
    end loop;
    end;
$$;

alter function nettoiesujet() owner to postgres;

