create function inseradmi(serie text, reference_cindoc text, article text, discriminant text) returns void
  language plpgsql
as
$$
BEGIN
INSERT INTO Administratif VALUES(serie,reference_cindoc,article,discriminant);
END
$$;

alter function inseradmi(text, text, text, text) owner to postgres;

